# html-node-values

Для запуска `npm install && npm start`. После этого открыть http://localhost:5000/.

Решение можно писать в файле `src/main.js` (HMR не доступен, необходимо обновлять страницу вручную).
